/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EE333;

/**
 *
 * @author Blayde
 */
enum ShippingContentsType { Typical,Breakable,Perishable,Flammable;}
enum ImportStatus { Unknown,InProgress,Successful,Failure;}
enum ExportStatus { Unknown,InProgress,Successful,Failure;}

public class P3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
